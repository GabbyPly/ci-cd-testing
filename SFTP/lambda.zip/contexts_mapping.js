const contextsMapping = [];

module.exports = contextsMapping;
