module.exports = {
    beforeMiddlewares: [],
    afterMiddlewares: []
}