const DIRECTORY_PATH = './';
const DIRECTORY_NAME = 'My directory';
const typeDir = 'd';
module.exports = { DIRECTORY_NAME, DIRECTORY_PATH, typeDir };
